/*
package morechem.recipe;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.Mod;

public class CombinerRecipeRegistrar {
	public CombinerRecipeRegistrar() {
	}

	@SubscribeEvent
	public static void init(FMLInitializationEvent event) {
		new CombinerRecipeRegistrar();
	}

	@SubscribeEvent
	public void preInit(FMLPreInitializationEvent event) {
	}
	@Mod.EventBusSubscriber
	private static class ForgeBusEvents {
		@SubscribeEvent
		public static void serverLoad(FMLServerStartingEvent event) {
		}

		@OnlyIn(Dist.CLIENT)
		@SubscribeEvent
		public static void clientLoad(FMLServerStartingEvent event) {
		}
	}
}

*/