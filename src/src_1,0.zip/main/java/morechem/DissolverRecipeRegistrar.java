// Minecraft Forge 1.12.2 mod
package morechem.recipe;

import al132.alchemistry.recipes.DissolverRecipe;
import al132.alchemistry.recipes.ModRecipes;
import al132.alchemistry.recipes.ProbabilityGroup;
import al132.alchemistry.recipes.ProbabilitySet;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.oredict.OreDictionary;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List; //////////
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;


public class DissolverRecipeRegistrar {
// L = recipeLines

// ex:    input, reversible, quantity, rolls, relative,   prob, out, prob, out...
// reversible - auto add to  Combiner
// quantity - input count
// rolls -  roll count
// relative - type (Absolute/Relative)

private static final List<String> L = Collections.unmodifiableList(Arrays.asList(
"morechem:compound_1,   true, 1, 1, false, 100, alchemistry:element:47*2, alchemistry:element:6*2",
"morechem:compound_2,   true, 1, 1, false, 100, alchemistry:element:6*2,  alchemistry:element:8*4",
"morechem:compound_3,   true, 1, 1, false, 100, alchemistry:element:6,    alchemistry:element:8*3",
"morechem:compound_4,   true, 1, 1, false, 100, alchemistry:element:47*2, alchemistry:element:24*2, alchemistry:element:8*7",
"morechem:compound_5,   true, 1, 1, false, 100, alchemistry:element:24,   alchemistry:element:8*4",
"morechem:compound_6,   true, 1, 1, false, 100, alchemistry:element:42,   alchemistry:element:8*4",
"morechem:compound_7,   true, 1, 1, false, 100, alchemistry:element:34,   alchemistry:element:8*3",
"morechem:compound_8,   true, 1, 1, false, 100, alchemistry:element:34,   alchemistry:element:8*4",
"morechem:compound_9,   true, 1, 1, false, 100, alchemistry:element:16,   alchemistry:element:8*4",
"morechem:compound_10,  true, 1, 1, false, 100, alchemistry:element:15,   alchemistry:element:8*4",
"morechem:compound_11,  true, 1, 1, false, 100, alchemistry:element:35,   alchemistry:element:8*3",
"morechem:compound_12,  true, 1, 1, false, 100, alchemistry:element:6*2,  alchemistry:element:1*3,  alchemistry:element:8*2",
"morechem:compound_13,  true, 1, 1, false, 100, alchemistry:element:17,   alchemistry:element:8*3",
"morechem:compound_14,  true, 1, 1, false, 100, alchemistry:element:17,   alchemistry:element:8*4",
"morechem:compound_15,  true, 1, 1, false, 100, alchemistry:element:6,    alchemistry:element:7",
"morechem:compound_16,  true, 1, 1, false, 100, alchemistry:element:47,   morechem:compound_102",
"morechem:compound_17,  true, 1, 1, false, 100, alchemistry:element:53,   alchemistry:element:8*3",
"morechem:compound_18,  true, 1, 1, false, 100, alchemistry:element:25,   alchemistry:element:8*4",
"morechem:compound_19,  true, 1, 1, false, 100, alchemistry:element:7,    alchemistry:element:8*3",
"morechem:compound_20,  true, 1, 1, false, 100, alchemistry:element:16,   alchemistry:element:6,    alchemistry:element:7",
"morechem:compound_21,  true, 1, 1, false, 100, alchemistry:element:11,   alchemistry:element:1,    morechem:compound_3",
"morechem:compound_22,  true, 1, 1, false, 100, alchemistry:element:13*2, alchemistry:element:8",
"morechem:compound_23,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:8",
"morechem:compound_24,  true, 1, 1, false, 100, alchemistry:element:6,    alchemistry:element:8*2",
"morechem:compound_25,  true, 1, 1, false, 100, alchemistry:element:13*2, alchemistry:element:16*3",
"morechem:compound_26,  true, 1, 1, false, 100, alchemistry:element:11*3, alchemistry:element:13,   alchemistry:element:9*6",
"morechem:compound_27,  true, 1, 1, false, 100, alchemistry:element:13*4, alchemistry:element:6*3",
"morechem:compound_28,  true, 1, 1, false, 100, alchemistry:element:13*6, alchemistry:element:14*2, alchemistry:element:8*13",
"morechem:compound_29,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:17*2",
"morechem:compound_30,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:17*3",
"morechem:compound_31,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:17*4",
"morechem:compound_32,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:17*6",
// 33
"morechem:compound_34,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:17*4, alchemistry:element:37",
"morechem:compound_35,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:17*6, alchemistry:element:19",
"morechem:compound_36,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:17*6, alchemistry:element:11",
"morechem:compound_37,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:9*4",
"morechem:compound_38,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:9*4,  alchemistry:element:3",
"morechem:compound_39,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:9*6,  alchemistry:element:11*3",
"morechem:compound_40,  true, 1, 1, false, 100, alchemistry:element:13,   alchemistry:element:31,   alchemistry:element:49, alchemistry:element:15",
"morechem:compound_41,  true, 1, 1, false, 100, alchemistry:element:33,   alchemistry:element:1*3",
"morechem:compound_42,  true, 1, 1, false, 100, alchemistry:element:5*3,  alchemistry:element:1*6,  alchemistry:element:7*3",
"morechem:compound_43,  true, 1, 1, false, 100, alchemistry:element:56,   alchemistry:element:35,   alchemistry:element:8*3, alchemistry:compound:7*2",
"morechem:compound_44,  true, 1, 1, false, 100, alchemistry:element:56,   alchemistry:element:35*2, alchemistry:element:8*6, alchemistry:compound:7*2",
"morechem:compound_45,  true, 1, 1, false, 100, alchemistry:element:56,   alchemistry:element:26,   alchemistry:element:14*4,alchemistry:element:8*10",
"morechem:compound_46,  true, 1, 1, false, 100, alchemistry:element:56,   alchemistry:element:52,   alchemistry:element:8*4, alchemistry:compound:7*3",
"morechem:compound_47,  true, 1, 1, false, 100, alchemistry:element:6*2,  alchemistry:element:1*2",
"morechem:compound_48,  true, 1, 1, false, 100, morechem:compound_150,    morechem:compound_151,    alchemistry:compound:15",
"morechem:compound_49,  true, 1, 1, false, 100, alchemistry:element:6*2,  alchemistry:element:1*5,  alchemistry:compound:27",
"morechem:compound_50,  true, 1, 1, false, 100, alchemistry:element:6*2,  alchemistry:element:1*5,  morechem:compound_117",
"morechem:compound_51,  true, 1, 1, false, 100, alchemistry:element:1,    alchemistry:element:7,    alchemistry:element:8*3",
"morechem:compound_52,  true, 1, 1, false, 100, morechem:compound_152,    morechem:compound_19*3",
"morechem:compound_53,  true, 1, 1, false, 100, morechem:compound_153,    morechem:compound_117,    alchemistry:element:16",
"morechem:compound_54,  true, 1, 1, false, 100, morechem:compound_153,    morechem:compound_19",
"morechem:compound_55,  true, 1, 1, false, 100, alchemistry:element:6*4,  alchemistry:element:1*8,  alchemistry:element:7*2, alchemistry:element:8*3",
"morechem:compound_56,  true, 1, 1, false, 100, alchemistry:element:6*6,  alchemistry:element:1*5,  alchemistry:element:8*2, alchemistry:element:7",
"morechem:compound_57,  true, 1, 1, false, 100, alchemistry:element:6*5,  alchemistry:element:1*10, alchemistry:element:7*2, alchemistry:element:8*3",
"morechem:compound_58,  true, 1, 1, false, 100, morechem:compound_155,    morechem:compound_154,    alchemistry:compound:15",
"morechem:compound_59,  true, 1, 1, false, 100, alchemistry:element:6*6,  alchemistry:element:1*8,  alchemistry:element:8*7",
"morechem:compound_60,  true, 1, 1, false, 100, alchemistry:element:6*10, alchemistry:element:1*22",
"morechem:compound_61,  true, 1, 1, false, 100, alchemistry:element:6*12, alchemistry:element:1*26",
"morechem:compound_62,  true, 1, 1, false, 100, alchemistry:element:6*14, alchemistry:element:1*18, alchemistry:element:7*2, alchemistry:element:8*5",
"morechem:compound_63,  true, 1, 1, false, 100, alchemistry:element:6*18, alchemistry:element:1*32, alchemistry:element:8*2",
"morechem:compound_64,  true, 1, 1, false, 100, morechem:compound_116,    100, morechem:compound_117*3",
"morechem:compound_65,  true, 1, 1, false, 100, alchemistry:element:6*18, alchemistry:element:1*38",
"morechem:compound_66,  true, 1, 1, false, 100, alchemistry:element:6*20, alchemistry:element:1*24, alchemistry:element:8*2, alchemistry:element:7*2",
"morechem:compound_67,  true, 1, 1, false, 100, alchemistry:element:6*20, alchemistry:element:1*42",
"morechem:compound_68,  true, 1, 1, false, 100, alchemistry:element:6*2,  alchemistry:element:9*3,  alchemistry:element:17*3",
"morechem:compound_69,  true, 1, 1, false, 100, morechem:compound_154,    alchemistry:element:17*2",
"morechem:compound_70,  true, 1, 1, false, 100, morechem:compound_154,    morechem:compound_151",
"morechem:compound_71,  true, 1, 1, false, 100, morechem:compound_154,    alchemistry:element:8*1",
"morechem:compound_72,  true, 1, 1, false, 100, morechem:compound_154*2,  alchemistry:compound:15*2",
"morechem:compound_73,  true, 1, 1, false, 100, morechem:compound_150,    morechem:compound_154*16, alchemistry:element:6,   alchemistry:element:8*2, alchemistry:element:1",
"morechem:compound_74,  true, 1, 1, false, 100, morechem:compound_150,    alchemistry:element:6*2,  alchemistry:element:1",
"morechem:compound_75,  true, 1, 1, false, 100, morechem:compound_150,    morechem:compound_154*3,  alchemistry:compound:15",
"morechem:compound_76,  true, 1, 1, false, 100, morechem:compound_150,    morechem:compound_154,    morechem:compound_151,   alchemistry:compound:27",
"morechem:compound_77,  true, 1, 1, false, 100, morechem:compound_150*2,  morechem:compound_154*2,  alchemistry:element:8",
"morechem:compound_78,  true, 1, 1, false, 100, morechem:compound_150,    morechem:compound_154,    alchemistry:compound:15",
"morechem:compound_79,  true, 1, 1, false, 100, morechem:compound_150,    morechem:compound_154,    alchemistry:element:6,   alchemistry:element:1",
"morechem:compound_80,  true, 1, 1, false, 100, morechem:compound_150*2,  morechem:compound_151",
"morechem:compound_81,  true, 1, 1, false, 100, morechem:compound_150,    morechem:compound_151,    alchemistry:element:17",
"morechem:compound_82,  true, 1, 1, false, 100, morechem:compound_150,    alchemistry:element:6,    alchemistry:element:8*2",
"morechem:compound_83,  true, 1, 1, false, 100, morechem:compound_150*3,  morechem:compound_154*2,  alchemistry:element:6*2, alchemistry:element:8*2, alchemistry:element:1",
"morechem:compound_84,  true, 1, 1, false, 100, morechem:compound_150*3,  alchemistry:element:6*8,  alchemistry:element:1*7, alchemistry:element:8*2",
"morechem:compound_85,  true, 1, 1, false, 100, morechem:compound_150*3,  alchemistry:element:6*3,  alchemistry:element:1*3, alchemistry:element:8*2",
"morechem:compound_86,  true, 1, 1, false, 100, alchemistry:element:6*45, alchemistry:element:1*73, alchemistry:element:7,   alchemistry:element:8*15",
"morechem:compound_87,  true, 1, 1, false, 100, alchemistry:element:6,    alchemistry:element:1,    alchemistry:element:17*3",
"morechem:compound_88,  true, 1, 1, false, 100, alchemistry:element:29,   alchemistry:compound:7*4, morechem:compound_9, 100, alchemistry:compound:7",
"morechem:compound_89,  true, 1, 1, false, 100, alchemistry:element:29*2, morechem:compound_3,      alchemistry:compound:15*2",
"morechem:compound_90,  true, 1, 1, false, 100, alchemistry:element:29,   alchemistry:element:26,   alchemistry:element:16*2",
"morechem:compound_91,  true, 1, 1, false, 100, morechem:deiterium*2,     alchemistry:element:8",
"morechem:compound_92,  true, 1, 1, false, 100, alchemistry:element:31*2, morechem:compound_9*3,    100, alchemistry:compound:7*18",
"morechem:compound_93,  true, 1, 1, false, 100, alchemistry:element:1*6,  alchemistry:element:6*3,  alchemistry:element:8*3",
"morechem:compound_94,  true, 1, 1, false, 100, alchemistry:element:1*8,  alchemistry:element:6*6,  alchemistry:element:8*6",

"morechem:compound_95,  true, 1, 1, false, 100, alchemistry:element:1*18, alchemistry:element:6*12, alchemistry:element:8, alchemistry:element:7*4, alchemistry:element:16, alchemistry:element:17*2",

"morechem:compound_96,  true, 1, 1, false, 100, alchemistry:element:12,   morechem:compound_3",
"morechem:compound_97,  true, 1, 1, false, 100, alchemistry:element:7*2,  alchemistry:element:1*4",
"morechem:compound_98,  true, 1, 1, false, 100, alchemistry:compound:27*2,morechem:compound_151",
"morechem:compound_99,  true, 1, 1, false, 100, alchemistry:compound:29*2,morechem:compound_19",
"morechem:compound_100, true, 1, 1, false, 100, alchemistry:element:8*3",
"morechem:compound_101, true, 1, 1, false, 100, alchemistry:element:39*2, alchemistry:element:8*3",
"morechem:compound_102, true, 1, 1, false, 100, alchemistry:element:6,    alchemistry:element:7,    alchemistry:element:8",
"morechem:compound_103, true, 1, 1, false, 100, alchemistry:element:20,   alchemistry:element:8",
"morechem:compound_104, true, 1, 1, false, 100, alchemistry:element:7,    alchemistry:element:1*3",
"morechem:compound_105, true, 1, 1, false, 100, morechem:compound_9,      alchemistry:element:1*2",
"morechem:compound_106, true, 1, 1, false, 100, alchemistry:element:16,   alchemistry:element:8*3",
"morechem:compound_107, true, 1, 1, false, 100, alchemistry:element:6*2,  alchemistry:element:1*4",
"morechem:compound_108, true, 1, 1, false, 100, alchemistry:element:6*3,  alchemistry:element:1*6",
"morechem:compound_109, true, 1, 1, false, 100, alchemistry:element:6*8,  alchemistry:element:1*8",
"morechem:compound_110, true, 1, 1, false, 100, alchemistry:element:82,   alchemistry:element:7*6",
"morechem:compound_111, true, 1, 1, false, 100, alchemistry:element:26,   alchemistry:element:16",
"morechem:compound_112, true, 1, 1, false, 100, alchemistry:element:26,   alchemistry:element:73,   alchemistry:element:8*4",
"morechem:compound_113, true, 1, 1, false, 100, alchemistry:compound:1*2, alchemistry:element:21*2, alchemistry:element:8*3",
"morechem:compound_114, true, 1, 1, false, 100, alchemistry:compound:26,  alchemistry:element:22,   alchemistry:element:8*3",
// 115
"morechem:compound_116, true, 1, 1, false, 100, morechem:compound_155,    morechem:compound_150",
"morechem:compound_117, true, 1, 1, false, 100, alchemistry:element:7,    alchemistry:element:8*2",
"morechem:compound_118, true, 1, 1, false, 100, alchemistry:element:6*6,  alchemistry:element:1*7, alchemistry:element:7*3, alchemistry:element:8*11",

"morechem:compound_119, true, 1, 1, false, 100, morechem:compound_157,    morechem:compound_117*3, alchemistry:compound:15",
"morechem:compound_120, true, 1, 1, false, 100, morechem:compound_157,    morechem:compound_117*3, alchemistry:compound:27, alchemistry:compound:15",
"morechem:compound_121, true, 1, 1, false, 100, alchemistry:element:6*12, alchemistry:element:1*5, alchemistry:element:7*7, alchemistry:element:8*12",
"morechem:compound_122, true, 1, 1, false, 100, morechem:compound_152,    alchemistry:element:7*3, alchemistry:element:8*9",
"morechem:compound_123, true, 1, 1, false, 100, morechem:compound_127*2,  morechem:compound_64",
"morechem:compound_124, true, 1, 1, false, 100, morechem:compound_158,    morechem:compound_19*4",
"morechem:compound_125, true, 1, 1, false, 100, morechem:compound_64*2,   morechem:compound_159",
"morechem:compound_126, true, 1, 1, false, 100, morechem:compound_124,    morechem:compound_160",
"morechem:compound_127, true, 1, 1, false, 100, alchemistry:element:6*4,  alchemistry:element:1*8, alchemistry:element:7*8, alchemistry:element:8*8",
"morechem:compound_128, true, 1, 1, false, 100, alchemistry:element:6*7,  alchemistry:element:1*5, alchemistry:element:7*5, alchemistry:element:8*8",
// 129
"morechem:compound_130, true, 1, 1, false, 100, alchemistry:element:6*10, alchemistry:element:1*8, 100, morechem:compound_99",
"morechem:compound_131, true, 1, 1, false, 100, morechem:compound_102*6,  morechem:compound_161*6",
"morechem:compound_132, true, 1, 1, false, 100, morechem:compound_99,     morechem:compound_64,    alchemistry:element:13*4",
// 133
"morechem:compound_134, true, 1, 1, false, 100, alchemistry:element:6*3,  alchemistry:element:1*4, alchemistry:element:7*4, alchemistry:element:8*6",
"morechem:compound_135, true, 1, 1, false, 100, alchemistry:element:6*2,  alchemistry:element:1*4, alchemistry:element:7*4, alchemistry:element:8*4",
"morechem:compound_136, true, 1, 1, false, 100, alchemistry:element:6*8,  alchemistry:element:1*8, alchemistry:element:7*2, alchemistry:element:8*5",
"morechem:compound_137, true, 1, 1, false, 100, morechem:compound_99,     100, alchemistry:compound*4,  100, alchemistry:element:13*2",
"morechem:compound_138, true, 1, 1, false, 100, alchemistry:element:6*6,  alchemistry:element:1*6, alchemistry:element:7*6, alchemistry:element:8*6",
"morechem:compound_139, true, 1, 1, false, 100, alchemistry:element:6*8,  morechem:compound_117*8",
"morechem:compound_140, true, 4, 1, false, 100, alchemistry:element:6*4,  alchemistry:element:1*6",
"morechem:compound_141, true, 1, 4, false, 100, morechem:compound_152,    alchemistry:element:7*3, alchemistry:element:8",


"morechem:compound_142, true, 1, 1, false, 100, alchemistry:element:26,   alchemistry:element:16*2",
"morechem:compound_143, true, 1, 1, false, 100, alchemistry:element:82,   alchemistry:element:16",
"morechem:compound_144, true, 1, 1, false, 100, alchemistry:element:12*2, alchemistry:element:16,   alchemistry:element:14,  alchemistry:element:8*4",
"morechem:compound_145, true, 1, 1, false, 100, alchemistry:element:26*7, alchemistry:element:16*8",
"morechem:compound_146, true, 1, 1, false, 100, alchemistry:compound:43,  alchemistry:compound:7*7",
"morechem:compound_147, true, 1, 1, false, 100, morechem:compound_150,    alchemistry:compound:15",
"morechem:compound_148, true, 1, 1, false, 100, alchemistry:element:20,   alchemistry:element:13*2, alchemistry:element:14*2,alchemistry:element:8*8",
"morechem:compound_149, true, 1, 1, false, 100, alchemistry:element:1*2,  alchemistry:element:16",
"morechem:compound_150, true, 1, 1, false, 100, alchemistry:element:6,    alchemistry:element:1*4",
"morechem:compound_151, true, 1, 1, false, 100, alchemistry:element:6,    alchemistry:element:8",
"morechem:compound_152, true, 1, 1, false, 100, alchemistry:element:6*3,  alchemistry:element:1*5",
"morechem:compound_153, true, 1, 1, false, 100, alchemistry:element:6*3,  alchemistry:element:1*7",
"morechem:compound_154, true, 1, 1, false, 100, alchemistry:element:6,    alchemistry:element:1*2",
"morechem:compound_155, true, 1, 1, false, 100, alchemistry:element:6*6,  alchemistry:element:1*5",
"morechem:compound_156, true, 1, 1, false, 100, alchemistry:element:6*20, alchemistry:element:1*25, alchemistry:element:7*3, alchemistry:element:8",
"morechem:compound_157, true, 1, 1, false, 100, alchemistry:element:6*6,  alchemistry:element:1*2",
"morechem:compound_158, true, 1, 1, false, 100, alchemistry:element:6*5,  alchemistry:element:1*8",
"morechem:compound_159, true, 1, 1, false, 100, alchemistry:compound:34,  alchemistry:element:1*8,  alchemistry:element:7*4, alchemistry:element:8*2",
"morechem:compound_160, true, 1, 1, false, 100, alchemistry:element:6*3,  morechem:compound_161*3",
"morechem:compound_161, true, 1, 1, false, 100, alchemistry:element:1, alchemistry:element:7, alchemistry:element:8",



// minecraft addition


"minecraft:poisonous_potato, false, 1, 1, false, 5,   morechem:compound_86, 10, alchemistry:compound:19, 20, alchemistry:element:19*5",
"minecraft:sponge:1,         false, 1, 1, false, 100, alchemistry:compound:8*8, alchemistry:compound:13*8, alchemistry:compound:7*16",
"minecraft:bowl, 			 false, 1, 1, false, 15,  alchemistry:compound",
"minecraft:cooked_fish,      false, 1, 1, false, 100, alchemistry:compound:9*4, alchemistry:element:34*2",
"minecraft:cooked_fish:1,    false, 1, 1, false, 100, alchemistry:compound:9*4, alchemistry:element:34*4",

"minecraft:magma_cream,      false, 1, 1, true,  10,  alchemistry:element:25, 1.25,alchemistry:element:13,5,alchemistry:compound:4,0.5,alchemistry:compound:5,2.5,alchemistry:compound:1,5,alchemistry:element:16,2.5,alchemistry:compound:10,2,alchemistry:element:82,1,alchemistry:element:9,1,alchemistry:element:35",
"minecraft:fermented_spider_eye,false,1,1,false, 100, alchemistry:compound:9*2, alchemistry:compound:52*2, 100, alchemistry:compound, alchemistry:compound:21, 100, alchemistry:compound:11",
"minecraft:rabbit_foot,      false, 1, 1, false, 100, alchemistry:compound:9*2",
"minecraft:cookie,      	 false, 1, 1, false, 100, alchemistry:compound:59, alchemistry:compound, 10, alchemistry:compound:19",
"minecraft:speckled_melon,	 false, 1, 1, false, 100, alchemistry:element:79*8, 10, alchemistry:compound:20, 2, alchemistry:compound:7, 1, alchemistry:compound:11",
"minecraft:melon,	 		 false, 1, 1, true,  416, minecraft:air, 50,  alchemistry:compound:20, 1,alchemistry:compound:7*4,1, alchemistry:compound:11*2",
"minecraft:pumpkin_pie,	     false, 1, 1, true,  50,  alchemistry:compound:20, 100, alchemistry:compound:11, alchemistry:compound:13*8, alchemistry:compound:9*2",

"minecraft:stone_button,     false, 1, 1,  true, 20,  minecraft:air, 2,alchemistry:element:13,4,alchemistry:element:26,1.5,alchemistry:element:79,20,alchemistry:compound:1,0.5,alchemistry:element:66,1.25,alchemistry:element:40,1,alchemistry:element:74,1,alchemistry:element:28,1,alchemistry:element:31",
"minecraft:wooden_button,    false, 1, 1,  false,25 , alchemistry:compound",
"minecraft:stone_pressure_plate, false,1,2,true, 100, minecraft:air, 2,alchemistry:element:13,4,alchemistry:element:26,1.5,alchemistry:element:79,20,alchemistry:compound:1,0.5,alchemistry:element:66,1.25,alchemistry:element:40,1,alchemistry:element:74,1,alchemistry:element:28,1,alchemistry:element:31",
"minecraft:wooden_pressure_plate,false,1,1,false,50,  alchemistry:compound",
"minecraft:tripwire_hook,    false, 1, 8,  false,12.5, alchemistry:element:26, 1.875, alchemistry:compound",
"minecraft:light_weighted_pressure_plate,  false,1,1,false,100, alchemistry:element:79*32",
"minecraft:heavy_weighted_pressure_plate,  false,1,1,false,100, alchemistry:element:26*32",
"minecraft:redstone_torch,   false, 1, 1,  false,100, alchemistry:compound:10, alchemistry:compound:17, 10, alchemistry:compound",

"minecraft:sandstone,        false, 1, 1,  false,100, alchemistry:compound:1*8, 2, alchemistry:element:79",
"minecraft:sandstone:1,      false, 1, 1,  false,100, alchemistry:compound:1*8, 2, alchemistry:element:79",
"minecraft:sandstone:2,      false, 1, 1,  false,100, alchemistry:compound:1*8, 2, alchemistry:element:79",
"minecraft:stone_slab:1,     false, 1, 1,  false,50,  alchemistry:compound:1*8, 1, alchemistry:element:79",
"minecraft:sandstone_stairs, false, 1, 1,  false,75,  alchemistry:compound:1*8, 1.5, alchemistry:element:79",

"minecraft:red_sandstone,    false, 1, 1,  false,100, alchemistry:compound:1*8, 20, alchemistry:compound:10",
"minecraft:red_sandstone:1,  false, 1, 1,  false,100, alchemistry:compound:1*8, 20, alchemistry:compound:10",
"minecraft:red_sandstone:2,  false, 1, 1,  false,100, alchemistry:compound:1*8, 20, alchemistry:compound:10",
"minecraft:stone_slab2,      false, 1, 1,  false,50,  alchemistry:compound:1*8, 10, alchemistry:compound:10",
"minecraft:red_sandstone_stairs,false,1,1, false,75,  alchemistry:compound:1*8, 15, alchemistry:compound:10",

"minecraft:purpur_slab,      false, 1, 1,  false,50 , alchemistry:compound:1*4, 25,  alchemistry:element:71",
"minecraft:red_sandstone_stairs,false,1,1, false,75,  alchemistry:compound:1*4,37.5, alchemistry:element:71",

"minecraft:brick,			 false,1,1, false,   100, alchemistry:compound:8",
"minecraft:brick_block,		 false,1,1, false,   100, alchemistry:compound:8*4",
"minecraft:stone_slab:4,	 false,1,1, false,   100, alchemistry:compound:8*2",
"minecraft:brick_stairs,	 false,1,1, false,   100, alchemistry:compound:8*3",

"minecraft:milk_bucket,		 false,1,1, false,   100, alchemistry:element:26*48,alchemistry:compound:9*2, alchemistry:compound:7*16, alchemistry:compound:11",
"minecraft:book,			 false,1,1, false,   100, alchemistry:compound:9*3, alchemistry:compound*9"


// ... others
));




// cache for parseItemStack: specification -> ItemStack (prototype). We will clone only when we need to change count.
private static final Map<String, ItemStack> ITEM_CACHE = new ConcurrentHashMap<>(512);

// reflection cache: methods/fields (initialized once)
private static final Method REF_setInput;
private static final Method REF_setReversible;
private static final Method REF_setOutputs;
private static final Field FIELD_input;
private static final Field FIELD_reversible;
private static final Field FIELD_outputs;

// how to add to ModRecipes: either the add(DissolverRecipe) method or a list field
private static final Method MODRECIPES_ADD_METHOD;
private static final Field MODRECIPES_LIST_FIELD;


static {
    Method mSetInput = null, mSetRev = null, mSetOut = null;
    Field fInput = null, fRev = null, fOut = null;
    Method addMethod = null;
    Field listField = null;

    try {
        mSetInput = DissolverRecipe.class.getMethod("setInput", Ingredient.class);
        mSetRevoke: {}
    } catch (Exception ignored) { mSetInput = null; }

    try {
        mSetRev = DissolverRecipe.class.getMethod("setReversible", boolean.class);
    } catch (Exception ignored) { mSetRev = null; }

    try {
        mSetOut = DissolverRecipe.class.getMethod("set_outputs", ProbabilitySet.class);
    } catch (Exception ignored) { mSetOut = null; }

    // fallback to fields if methods absent
    try {
        fInput = DissolverRecipe.class.getDeclaredField("input");
        fInput.setAccessible(true);
    } catch (Exception ignored) { fInput = null; }

    try {
        fRev = DissolverRecipe.class.getDeclaredField("reversible");
        fRev.setAccessible(true);
    } catch (Exception ignored) { fRev = null; }

    try {
        fOut = DissolverRecipe.class.getDeclaredField("_outputs");
        fOut.setAccessible(true);
    } catch (Exception ignored) { fOut = null; }

    // find add method in ModRecipes
    for (Method m : ModRecipes.class.getMethods()) {
        if (m.getParameterCount() == 1 && m.getParameterTypes()[0].equals(DissolverRecipe.class)) {
            String n = m.getName().toLowerCase();
            if (n.contains("dissolver") || n.contains("add")) {
                addMethod = m;
                break;
            }
        }
    }

    if (addMethod == null) {
        try {
            Field ff = ModRecipes.class.getDeclaredField("dissolverRecipes");
            ff.setAccessible(true);
            listField = ff;
        } catch (Exception ignored) { listField = null; }
    }

    REF_setInput = mSetInput;
    REF_setReversible = mSetRev;
    REF_setOutputs = mSetOut;
    FIELD_input = fInput;
    FIELD_reversible = fRev;
    FIELD_outputs = fOut;
    MODRECIPES_ADD_METHOD = addMethod;
    MODRECIPES_LIST_FIELD = listField;
}




////////////////////////////////////////////////

    public static void registerAll() {
        for (String line : L) {
            try {
                parseAndRegister(line);
            } catch (Exception e) {
            	System.out.println("Ooooops! Thats's error, pls report it on Github. [MCRX]");
                e.printStackTrace();
            }
        }
    }
////////////////////////////////////////////////
    private static void parseAndRegister(String line) {
        if (line == null || line.isEmpty()) return;

        // Parsing a string without split: getting tokens by comma, trim
        List<String> parts = splitByComma(line);
        if (parts.size() < 7) return;

        ItemStack input = parseItemStack(parts.get(0));
        if (input == null) return;

        boolean reversible = Boolean.parseBoolean(parts.get(1));
        int quantity = parseInt(parts.get(2), 1);
        if (quantity > 1) input = input.copy(); // cloning to avoid changing the cache prototype
        input.setCount(quantity);

        int rolls = parseInt(parts.get(3), 1);
        boolean relative = Boolean.parseBoolean(parts.get(4));

        // outputs: probability then one-or-more item specs
        List<ProbabilityGroup> groups = new ArrayList<>(Math.max(4, (parts.size()-5)/3));
        for (int i = 5; i < parts.size(); ) {
            double prob = parseDouble(parts.get(i), 100.0);
            i++;
            // collect following parts that look like item specs (contain ':')
            List<ItemStack> outs = new ArrayList<>(4);
            while (i < parts.size() && parts.get(i).indexOf(':') >= 0) {
                ItemStack outProto = parseItemStack(parts.get(i));
                if (outProto != null) {
                    outs.add(outProto.copy()); // creating a separate instance so that the group can store a unique stack
                }
                i++;
            }
            if (!outs.isEmpty()) {
                groups.add(new ProbabilityGroup(outs, prob));
            }
        }

        ProbabilitySet set = new ProbabilitySet(groups, relative, rolls);
        DissolverRecipe recipe = new DissolverRecipe();

        // applied via cached reflection (methods or fields)
        try {
            if (REF_setInput != null && REF_setReversible != null && REF_setOutputs != null) {
                REF_setInput.invoke(recipe, Ingredient.fromStacks(input));
                REF_setReversible.invoke(recipe, reversible);
                REF_setOutputs.invoke(recipe, set);
            } else {
                if (FIELD_input != null) FIELD_input.set(recipe, Ingredient.fromStacks(input));
                if (FIELD_reversible != null) FIELD_reversible.setBoolean(recipe, reversible);
                if (FIELD_outputs != null) FIELD_outputs.set(recipe, set);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        // add to ModRecipes - use the cached method or list
        try {
            if (MODRECIPES_ADD_METHOD != null) {
                MODRECIPES_ADD_METHOD.invoke(ModRecipes.INSTANCE, recipe);
                return;
            }
        } catch (Exception ignored) { }

        try {
            if (MODRECIPES_LIST_FIELD != null) {
                Object listObj = MODRECIPES_LIST_FIELD.get(ModRecipes.INSTANCE);
                if (listObj instanceof List) {
                    @SuppressWarnings("unchecked")
                    List<DissolverRecipe> list = (List<DissolverRecipe>) listObj;
                    list.add(recipe);
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

///////////////////////////////////////////////////////////////////

// Quick parser of the ItemStack specification:  "mod:item[:meta][*count]"
    private static ItemStack parseItemStack(String spec) {
        if (spec == null) return null;
        String s = spec.trim();
        if (s.isEmpty()) return null;

        // check cache
        ItemStack cached = ITEM_CACHE.get(s);
        if (cached != null) return cached.copy(); // returning a copy, caller decides to change counts

        int count = 1;
        int star = s.indexOf('*');
        if (star >= 0) {
            String cntStr = s.substring(star + 1).trim();
            count = parseInt(cntStr, 1);
            s = s.substring(0, star).trim();
        }

        // split by ':'
        int firstColon = s.indexOf(':');
        if (firstColon < 0) return null;
        int secondColon = s.indexOf(':', firstColon + 1);

        String modid;
        String name;
        String metaStr = null;
        if (secondColon >= 0) {
            modid = s.substring(0, firstColon);
            name = s.substring(firstColon + 1, secondColon);
            metaStr = s.substring(secondColon + 1);
        } else {
            modid = s.substring(0, firstColon);
            name = s.substring(firstColon + 1);
        }

        int meta = 0;
        if (metaStr != null) {
            String m = metaStr.trim();
            if ("*".equals(m)) meta = OreDictionary.WILDCARD_VALUE;
            else meta = parseInt(m, 0);
        }

        Item item = Item.REGISTRY.getObject(new ResourceLocation(modid, name));
        if (item == null) return null;

        ItemStack stack = (meta == OreDictionary.WILDCARD_VALUE)
                ? new ItemStack(item, count, OreDictionary.WILDCARD_VALUE)
                : new ItemStack(item, count, meta);

        // caching the prototype with count=1 so that you can copy and change count if necessary
        ItemStack proto = stack.copy();
        proto.setCount(1);
        ITEM_CACHE.put(s, proto);

        // return the stack with the required count
        if (stack.getCount() != 1) {
            ItemStack ret = proto.copy();
            ret.setCount(count);
            return ret;
        }
        return proto.copy();
    }

////////////////////////////////////////////////////////////////////

	// Quick comma split with trim (doesn't use regex)
    private static List<String> splitByComma(String line) {
        List<String> res = new ArrayList<>(8);
        int len = line.length();
        int i = 0;
        StringBuilder sb = new StringBuilder(32);
        while (i < len) {
            char c = line.charAt(i);
            if (c == ',') {
                String token = sb.toString().trim();
                if (!token.isEmpty()) res.add(token);
                sb.setLength(0);
                i++;
                continue;
            } else {
                sb.append(c);
            }
            i++;
        }
        String last = sb.toString().trim();
        if (!last.isEmpty()) res.add(last);
        return res;
    }




////////////////////////////////////////////////////////////////////

    private static int parseInt(String s, int def) {
        if (s == null) return def;
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    private static double parseDouble(String s, double def) {
        if (s == null) return def;
        try { return Double.parseDouble(s.trim()); } catch (Exception e) { return def; }
    }
}
